﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StreamCleanupAPI;
using StreamCleanupAPI.Controllers;
using StreamCleanupAPI.Interface;

namespace StreamCleanupAPI.Tests.Controllers
{
    [TestClass]
    public class StreamScoreControllerTest
    {
        IStreamScoreInfoService svc;

        [TestMethod]
        public void GetScore1()
        {
            string Strdata = "{{{}}}";
            int ScoreData = 6;
            svc = new StreamScoreInfoService();
            svc.SetStreamData(Strdata);

            StreamScoreController controller = new StreamScoreController(svc);

            IEnumerable<string> result = controller.Get();

            Assert.AreEqual(ScoreData.ToString(), result.ElementAt(0));

        }

        [TestMethod]
        public void GetScore2()
        {
            string Strdata = "{{},{}}";
            int ScoreData = 5;
            svc = new StreamScoreInfoService();
            svc.SetStreamData(Strdata);

            StreamScoreController controller = new StreamScoreController(svc);

            IEnumerable<string> result = controller.Get();

            Assert.AreEqual(ScoreData.ToString(), result.ElementAt(0));

        }

        [TestMethod]
        public void GetScore3()
        {
            string Strdata = "{{{}}}";
            int ScoreData = 6;
            svc = new StreamScoreInfoService();
            svc.SetStreamData(Strdata);

            StreamScoreController controller = new StreamScoreController(svc);

            IEnumerable<string> result = controller.Get();

            Assert.AreEqual(ScoreData.ToString(), result.ElementAt(0));

        }

        [TestMethod]
        public void GetScore4()
        {
            string Strdata = "{{{},{},{{}}}}";
            int ScoreData = 16;
            svc = new StreamScoreInfoService();
            svc.SetStreamData(Strdata);

            StreamScoreController controller = new StreamScoreController(svc);

            IEnumerable<string> result = controller.Get();

            Assert.AreEqual(ScoreData.ToString(), result.ElementAt(0));

        }

        [TestMethod]
        public void GetScore5()
        {
            string Strdata = "{<a>,<a>,<a>,<a>}";
            int ScoreData = 1;
            svc = new StreamScoreInfoService();
            svc.SetStreamData(Strdata);

            StreamScoreController controller = new StreamScoreController(svc);

            IEnumerable<string> result = controller.Get();

            Assert.AreEqual(ScoreData.ToString(), result.ElementAt(0));

        }

        [TestMethod]
        public void TestFileUpload1()
        {
            HttpClient client = new HttpClient();

            string FileName = "TestFiles\\SampleText1.txt";
            string FullPath = AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "\\" + FileName;

            if (File.Exists(FullPath))
            {
                MultipartFormDataContent formDataContent = new MultipartFormDataContent();

                StreamContent file1 = new StreamContent(File.OpenRead(FullPath));
                file1.Headers.ContentType = new MediaTypeHeaderValue("text/plain");
                file1.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data");
                file1.Headers.ContentDisposition.FileName = "FileName";
                formDataContent.Add(file1);

                // HttpResponseMessage response = client.PostAsync("http://loclhost:52631/api/StreamScore", formDataContent).Result;
            }

        }
    }
}
