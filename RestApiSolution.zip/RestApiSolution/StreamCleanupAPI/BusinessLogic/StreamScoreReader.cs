﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace StreamCleanupAPI.BusinessLogic
{

    public struct BracePair
    {
        private int startIndex;
        private int endIndex;
        private int depth;

        public BracePair(int startIndex, int endIndex, int depth)
        {
            if (startIndex > endIndex)
                throw new ArgumentException("startIndex must be less than endIndex");

            this.startIndex = startIndex;
            this.endIndex = endIndex;
            this.depth = depth;
        }

        public int StartIndex
        {
            get { return this.startIndex; }
        }

        public int EndIndex
        {
            get { return this.endIndex; }
        }

        public int Depth
        {
            get { return this.depth; }
        }
    }


    public class StreamScoreReader
    {
        private IEnumerable<BracePair> ParseBracePairs(string text)
        {
            var startPositions = new Stack<int>();

            for (int index = 0; index < text.Length; index++)
                if (text[index] == '{')
                {
                    startPositions.Push(index);
                }
                else if (text[index] == '}')
                {
                    if (startPositions.Count == 0)
                        throw new ArgumentException(string.Format("mismatched end Brace at index {0}", index));

                    var depth = startPositions.Count - 1;
                    var start = startPositions.Pop();

                    yield return new BracePair(start, index, depth);
                }

            if (startPositions.Count > 0)
                throw new ArgumentException(string.Format("mismatched start Braces, {0} total", startPositions.Count));
        }

        public int GetScore(string Input)
        {
            int TotalScore = 0;

            Dictionary<int, List<string>> MyDictionary = new Dictionary<int, List<string>>();   
	
            bool ValidGroupFlag = false;        

            foreach (var pairs in ParseBracePairs(Input))
            {

                ValidGroupFlag = false;         

                if (!MyDictionary.ContainsKey(pairs.Depth + 1))
                {
                    MyDictionary.Add(pairs.Depth + 1, new List<string>());
                }

                string temp = Input.Substring(pairs.StartIndex, pairs.EndIndex - pairs.StartIndex + 1);

	if (temp.Count(c => c == '{') == temp.Count(c => c == '}'))
                  {
                      temp = Regex.Replace(Input.Substring(pairs.StartIndex, pairs.EndIndex - pairs.StartIndex + 1), "!.", "");
	
	    if(pairs.Depth == 0)  //root Parent
	    {
		ValidGroupFlag = true;
	   }
	 else if (temp.Count(c => c == '>') > 0) // Should be atleast one '>' tag
	 {
		  if  ( temp.Count(c => c == '<') > 0)  // more <<< can be ignored
		      ValidGroupFlag = true;
		 else
		     ValidGroupFlag = false;
	 }
	else if ( (temp.Count(c => c == '<') == 0 &&  ( temp.Count(c => c == '>')==0)))
	{
		 ValidGroupFlag = true;
	}

	if (ValidGroupFlag ==true)
                        MyDictionary[pairs.Depth + 1].Add(Input.Substring(pairs.StartIndex, pairs.EndIndex - pairs.StartIndex + 1));
                    
                }
            }

            foreach (var item in MyDictionary)
            {
                TotalScore += item.Key * item.Value.Count;               
            }

            return TotalScore;
        }
       
    }
}