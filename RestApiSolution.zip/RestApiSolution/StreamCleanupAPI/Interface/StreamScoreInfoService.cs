﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using StreamCleanupAPI.BusinessLogic;

namespace StreamCleanupAPI.Interface
{
    public class StreamScoreInfoService : IStreamScoreInfoService
    {
        string StreamData = "";

        public StreamScoreInfoService()
        {
           
        }
        public void SetStreamData(string strData)
        {
            StreamData = strData;
        }

        public int GetScoreData()
        {
            StreamScoreReader _StreamScoreReader = new StreamScoreReader();
            return  _StreamScoreReader.GetScore(StreamData);
        }
    }
}