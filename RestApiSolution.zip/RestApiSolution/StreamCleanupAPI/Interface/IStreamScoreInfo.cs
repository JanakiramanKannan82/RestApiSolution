﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StreamCleanupAPI.Interface
{
    public interface IStreamScoreInfoService
    {
        void SetStreamData(string strData);
        int GetScoreData();
    }
}
